<script setup lang="ts">
defineOptions({
  // name 作为一种规范最好必须写上并且和路由的name保持一致
  name: "AI_dxl"
});
</script>

<style>
@import "/src/views/ai_dxl/ai_dxl.css";

/* 可以在这里继续添加其他样式规则 */

</style>

<template >
<div class = "page_back">
    <div>
      <h1 class = "ai_dxl_h1">大家好，我是冬雪莲</h1>
      <div>
        这是我们在大学期间做的第一个项目,它源自项目《云声知处--当中医药遇上虚拟主播》。<br>
        该项目在2023年第一届讯飞杯中取得了星火大模型赛道一等奖的成绩！<br>
        <img src="/src/views/ai_dxl/yunshengzhichu_logo.jpg" alt="云声知处logo"  width="300" height="200">
        左图是我们当时云声知处项目的logo。
      </div>
      <h3 class = "ai_dxl_h3">当然，后续肯定不止东雪莲一个Live2D模型。（各位二次元们可以好好期待一下/狗头）</h3>
      <h4>根据子标签可以访问各个虚拟玩伴，</h4>
      <h5>PS：各位，尽量少问点哈。用的是科大讯飞的token，总共就200万条，省着点用，谢谢🙏 ---hxx</h5>
    </div>
</div>

</template>


