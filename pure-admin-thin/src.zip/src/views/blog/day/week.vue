<script setup lang="ts">
defineOptions({
  // name 作为一种规范最好必须写上并且和路由的name保持一致
  name: "Weeklife"
});
</script>

<template>
  <h1>欢迎来到学习周报！</h1>
</template>