<script setup lang="ts">
defineOptions({
  // name 作为一种规范最好必须写上并且和路由的name保持一致
  name: "Class_Note"
});
</script>

<template>
  <h1>欢迎来到云课堂！</h1>
</template>