<script setup lang="ts">
defineOptions({
  // name 作为一种规范最好必须写上并且和路由的name保持一致
  name: "OJ_S"
});
</script>



<template >
<div >
   欢迎来到OJ社区！
</div>

</template>


