<script setup lang="ts">
defineOptions({
  // name 作为一种规范最好必须写上并且和路由的name保持一致
  name: "Community"
});
</script>

<template>
  <h1></h1>
</template>


